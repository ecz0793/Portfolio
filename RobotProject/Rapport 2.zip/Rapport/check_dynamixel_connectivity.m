function result = check_and_test_3_dynamixels()
% CHECK_AND_TEST_3_DYNAMIXELS
% Scans candidate ports for Dynamixel motors with IDs 1, 2, 3 at baud 1e6.
% For each detected motor:
%   1) ping motor
%   2) read present position
%   3) read present speed
%   4) command +10 steps from current position
%   5) read back position to verify command worked
%
% Assumptions:
% - Legacy Dynamixel SDK / Protocol 1.0
% - Present Position = address 36 (2 bytes)
% - Present Speed    = address 38 (2 bytes)
% - Goal Position    = address 30 (2 bytes)
%
% From your previous script, PORT=3 and BAUD=1000000 were already used,
% so COM4 / port index 3 is likely a good candidate to try first.
%
% Output:
%   result: struct with per-motor connectivity and motion test status

    clc;

    %% ---------------- USER SETTINGS ----------------
    candidatePorts = [3 0 1 2 4 5 6 7 8 9];   % try your usual port first
    candidateBaud  = 1e6;
    candidateIDs   = [1 2 3:100];
    moveSteps      = 30;
    maxRetries     = 3;
    waitAfterWrite = 0.5;   % seconds after sending motion command

    % Protocol 1.0 control table addresses
    ADDR_GOAL_POSITION    = 30;   % 2 bytes
    ADDR_PRESENT_POSITION = 36;   % 2 bytes
    ADDR_PRESENT_SPEED    = 38;   % 2 bytes

    %% ---------------- FILE PATHS ----------------
    dllPath = fullfile(pwd, 'dynamixel.dll');
    hPath   = fullfile(pwd, 'dynamixel.h');

    if ~exist(dllPath, 'file')
        error('dynamixel.dll not found in current folder.');
    end
    if ~exist(hPath, 'file')
        error('dynamixel.h not found in current folder.');
    end

    %% ---------------- LOAD LIBRARY ----------------
    libName = 'dynamixel';

    if libisloaded(libName)
        unloadlibrary(libName);
    end

    loadlibrary(dllPath, hPath);
    cleanupObj = onCleanup(@() safeTerminateAndUnload(libName)); %#ok<NASGU>

    %% ---------------- INIT RESULT ----------------
    result = struct();
    result.success = false;
    result.portIndex = [];
    result.portName = '';
    result.baudrate = candidateBaud;
    result.motors = repmat(struct( ...
        'id', [], ...
        'found', false, ...
        'positionBefore', [], ...
        'speedRaw', [], ...
        'speedRPM', [], ...
        'goalPosition', [], ...
        'positionAfter', [], ...
        'positionDelta', [], ...
        'moveCommandSent', false, ...
        'moveVerified', false, ...
        'message', ''), 1, numel(candidateIDs));

    for i = 1:numel(candidateIDs)
        result.motors(i).id = candidateIDs(i);
    end

    fprintf('\n=== Dynamixel connectivity + motion test ===\n');
    fprintf('Looking for IDs: [%s]\n', num2str(candidateIDs));
    fprintf('Baudrate fixed: %d\n\n', candidateBaud);

    %% ---------------- BAUDNUM ----------------
    baudnum = baudToBaudnum(candidateBaud);
    if isnan(baudnum)
        error('Could not convert baudrate %g to Dynamixel baudnum.', candidateBaud);
    end

    %% ---------------- PORT SCAN ----------------
    foundPort = false;

    for p = 1:numel(candidatePorts)
        portIdx = candidatePorts(p);

        fprintf('Trying port index %d (%s)...\n', portIdx, portIndexToName(portIdx));

        safeTerminate(libName);
        ok = calllib(libName, 'dxl_initialize', portIdx, baudnum);

        if ok ~= 1
            fprintf('  Failed to open port.\n\n');
            continue;
        end

        fprintf('  Port opened.\n');

        foundCount = 0;

        for i = 1:numel(candidateIDs)
            id = candidateIDs(i);
            fprintf('  Checking motor ID %d...\n', id);

            [isFound, pos, spd, msg] = testMotorRead(libName, id, ...
                ADDR_PRESENT_POSITION, ADDR_PRESENT_SPEED, maxRetries);

            result.motors(i).found = isFound;
            result.motors(i).positionBefore = pos;
            result.motors(i).speedRaw = spd;

            if ~isempty(spd)
                speedInfo = decodePresentSpeed(spd);
                result.motors(i).speedRPM = speedInfo.rpm;
            end

            result.motors(i).message = msg;

            if isFound
                foundCount = foundCount + 1;
                fprintf('    FOUND: pos=%d, speedRaw=%d, speedRPM=%.3f\n', ...
                    pos, spd, result.motors(i).speedRPM);
            else
                fprintf('    NOT FOUND: %s\n', msg);
            end
        end

        % accept this port if at least one expected motor responds
        if foundCount > 0
            result.portIndex = portIdx;
            result.portName = portIndexToName(portIdx);
            foundPort = true;
            fprintf('\nUsing port %s\n\n', result.portName);
            break;
        else
            fprintf('  No target motors found on this port.\n\n');
            safeTerminate(libName);
        end
    end

    if ~foundPort
        fprintf('No working port found for IDs 1,2,3.\n');
        return;
    end

    %% ---------------- MOTION TEST ----------------
    fprintf('=== Motion test: move each found motor by +10 steps ===\n');

    for i = 1:numel(candidateIDs)
        id = candidateIDs(i);

        if ~result.motors(i).found
            fprintf('ID %d skipped (not detected).\n', id);
            continue;
        end

        pos0 = result.motors(i).positionBefore;
        goal = pos0 + moveSteps;

        % Optional clamp for typical 10-bit range
        goal = max(0, min(1023, goal));

        fprintf('ID %d: current=%d -> goal=%d\n', id, pos0, goal);

        calllib(libName, 'dxl_write_word', id, ADDR_GOAL_POSITION, goal);
        comm = calllib(libName, 'dxl_get_result');

        if comm ~= 1
            result.motors(i).moveCommandSent = false;
            result.motors(i).message = sprintf('Write failed: %s', commResultToString(comm));
            fprintf('  Write failed: %s\n', commResultToString(comm));
            continue;
        end

        result.motors(i).moveCommandSent = true;
        result.motors(i).goalPosition = goal;

        pause(waitAfterWrite);

        pos1 = [];
        okReadback = false;
        for k = 1:maxRetries
            pos1 = calllib(libName, 'dxl_read_word', id, ADDR_PRESENT_POSITION);
            comm = calllib(libName, 'dxl_get_result');
            if comm == 1
                okReadback = true;
                break;
            end
            pause(0.05);
        end

        if ~okReadback
            result.motors(i).message = 'Move sent, but failed to read back position.';
            fprintf('  Could not read back position.\n');
            continue;
        end

        delta = pos1 - pos0;

        result.motors(i).positionAfter = pos1;
        result.motors(i).positionDelta = delta;

        % tolerate small delay / quantization
        if abs(delta) >= 1
            result.motors(i).moveVerified = true;
            result.motors(i).message = sprintf('Motion verified, delta=%d steps.', delta);
            fprintf('  Readback position=%d (delta=%d) -> OK\n', pos1, delta);
        else
            result.motors(i).moveVerified = false;
            result.motors(i).message = sprintf('Motor detected, but motion not clearly verified (delta=%d).', delta);
            fprintf('  Readback position=%d (delta=%d) -> unclear\n', pos1, delta);
        end
    end

    %% ---------------- GLOBAL STATUS ----------------
    foundAny = any([result.motors.found]);
    movedAny = any([result.motors.moveVerified]);

    result.success = foundAny;

    fprintf('\n=== Summary ===\n');
    fprintf('Port: %s, baud: %d\n', result.portName, result.baudrate);

    for i = 1:numel(result.motors)
        m = result.motors(i);
        fprintf('ID %d | found=%d | moveVerified=%d | %s\n', ...
            m.id, m.found, m.moveVerified, m.message);
    end

    if foundAny && movedAny
        fprintf('\nAt least one motor was detected and moved successfully.\n');
    elseif foundAny
        fprintf('\nMotors were detected, but motion verification was incomplete.\n');
    else
        fprintf('\nNo motors detected.\n');
    end
end


%% ====================== HELPERS ======================

function [isFound, pos, spd, msg] = testMotorRead(libName, id, addrPos, addrSpd, maxRetries)
    isFound = false;
    pos = [];
    spd = [];
    msg = 'Unknown error';

    for k = 1:maxRetries
        calllib(libName, 'dxl_ping', id);
        comm = calllib(libName, 'dxl_get_result');

        if comm ~= 1
            msg = sprintf('Ping failed: %s', commResultToString(comm));
            pause(0.05);
            continue;
        end

        pos = calllib(libName, 'dxl_read_word', id, addrPos);
        commPos = calllib(libName, 'dxl_get_result');

        if commPos ~= 1
            msg = sprintf('Position read failed: %s', commResultToString(commPos));
            pause(0.05);
            continue;
        end

        spd = calllib(libName, 'dxl_read_word', id, addrSpd);
        commSpd = calllib(libName, 'dxl_get_result');

        if commSpd ~= 1
            msg = sprintf('Speed read failed: %s', commResultToString(commSpd));
            pause(0.05);
            continue;
        end

        isFound = true;
        msg = 'Communication OK';
        return;
    end
end

function baudnum = baudToBaudnum(baud)
    switch baud
        case 1000000
            baudnum = 1;
        otherwise
            baudnum = round(2000000 / baud - 1);
            if baudnum < 0
                baudnum = NaN;
            end
    end
end

function s = portIndexToName(portIdx)
    s = sprintf('COM%d', portIdx + 1);
end

function info = decodePresentSpeed(rawSpeed)
    info = struct('magnitude', [], 'direction', '', 'rpm', []);

    if rawSpeed < 1024
        mag = rawSpeed;
        dir = 'CCW';
    else
        mag = rawSpeed - 1024;
        dir = 'CW';
    end

    info.magnitude = mag;
    info.direction = dir;
    info.rpm = mag * 0.111;
end

function txt = commResultToString(code)
    switch code
        case 0
            txt = 'COMM_TXSUCCESS';
        case 1
            txt = 'COMM_RXSUCCESS';
        case 2
            txt = 'COMM_TXFAIL';
        case 3
            txt = 'COMM_RXFAIL';
        case 4
            txt = 'COMM_TXERROR';
        case 5
            txt = 'COMM_RXWAITING';
        case 6
            txt = 'COMM_RXTIMEOUT';
        case 7
            txt = 'COMM_RXCORRUPT';
        otherwise
            txt = sprintf('UNKNOWN(%d)', code);
    end
end

function safeTerminate(libName)
    if libisloaded(libName)
        try
            calllib(libName, 'dxl_terminate');
        catch
        end
    end
end

function safeTerminateAndUnload(libName)
    if libisloaded(libName)
        try
            calllib(libName, 'dxl_terminate');
        catch
        end
        try
            unloadlibrary(libName);
        catch
        end
    end
end