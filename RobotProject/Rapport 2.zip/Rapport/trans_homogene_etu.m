function [H] = trans_homogene_etu(R,T)
% TRANS_HOMOGENE retourne la matrice de transformation homogene 3D
% correspondant à une rotation R et à une translation T successives. 

H = [ R(1,1) R(1,2) R(1,3) T(1); R(2,1) R(2,2) R(2,3) T(2); R(3,1) R(3,2) R(3,3) T(3); 0 0 0 1]

end