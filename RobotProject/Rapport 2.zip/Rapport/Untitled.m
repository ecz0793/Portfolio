
% Position Initiale 
x0 = 1;
y0 = 1;
theta0 =  pi/4;

% Position finale 
x_f     = -1;
y_f     = 1;
theta_f = pi/4;

maquette.setSpeed(1,80)
maquette.setSpeed(2,80)
maquette.setSpeed(3,80)
n = 50; % nombre de points intermediaire 

t = linspace(0, 1, n+1);
x_traj = x0+ t *(x_f - x0); %equation d'un segment 
y_traj = y0+ t *(y_f - y0);
theta_traj = theta0 + t*(theta_f - theta0);

q_traj = zeros(n+1, 3);  
q_prec = zeros(1, 3); 

for i = 1:n+1
    [q1, q2] = modele.mod_geo_inv(x_traj(i), y_traj(i), theta_traj(i));

    q1_steps = angle2step(sol1, 512);
    q2_steps = angle2step(sol2, 512);

    q1_ok = all(q1_steps >= val_min & q1_steps <= val_max); %On verifie qu'on ne depasse pas les limites 
    q2_ok = all(q2_steps >= val_min & q2_steps <= val_max);

    if q1_ok && q2_ok  %alors on choisit en fonction de la distance parcourue 
        
        dist1 = norm(q1 - q_prec);
        dist2 = norm(q2 - q_prec);
        if dist1 <= dist2
            q_traj(i,:) = q1;
        else
            q_traj(i,:) = q2;
        end
    elseif q1_ok
        q_traj(i,:) = q1;
    elseif sol2_ok
        q_traj(i,:) = q2;
    else
        error('inaccessible', i);
    end

    q_prec = q_traj(i,:);   % Mise à jour pour le prochain point
end


%%
x_reel = zeros(1, n+1);
y_reel = zeros(1, n+1);

steps_depart = angle2step(q_traj(1,:), 512);
steps_dl = limit(steps_depart, val_min, val_max);
maquette.setStepPosition([1,2,3], steps_dl);

% Boucle qui permet d'afficher en direct le robot sur le modele
 while any(maquette.isMoving([1, 2, 3]))
     p_c = maquette.getStepPosition([1, 2, 3]);
     q_c = step2angle(p_c, 512);
     modele.setAngularPosition(q_c);
     T_courant = modele.mod_geo_dir();
     x_c  = T_courant(1, 4);
     y_c  = T_courant(2, 4);
     modele.plot(0, 'red', 1);
     pause(0.05);
   
    end

for i = 1:n+1

    q_steps = angle2step(q_traj(i,:), 512);
    q_sl = limit(q_steps, val_min, val_max);
    
    maquette.setStepPosition([1,2,3], q_sl);

    while any(maquette.isMoving([1, 2, 3]))% Boucle qui permet d'afficher en direct le robot sur le modele
     p_c = maquette.getStepPosition([1, 2, 3]);
     q_c = step2angle(p_c, 512);
     modele.setAngularPosition(q_c);
     T_courant = modele.mod_geo_dir();
     x_c  = T_courant(1, 4);
     y_c  = T_courant(2, 4);
     modele.plot(0, 'red', 1);
     pause(0.05);
   
    end

    p_reel = maquette.getStepPosition([1,2,3]);
    q_reel = step2angle(p_reel, 512);

    modele.setAngularPosition(q_reel);
    T_reel = modele.mod_geo_dir();
    x_reel(i) = T_reel(1,4);
    y_reel(i) = T_reel(2,4);

    if i == 1
        modele.plot(0, 'red', 0);
    else
        modele.plot(1, 'red', 1);
    end
end

% Plus le nombre de points intermédiaires augmentent plus la trajectoire
% est droite  
