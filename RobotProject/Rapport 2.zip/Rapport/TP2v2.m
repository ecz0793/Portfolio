% L3 Elec/Méca – LU3MEE01
% TP2

clear
clc

% Paramètres de la communications série
PORT = 8;       % A modifier avec le n° du port COM utilisé

%% 2.1 Prise en main du contrôle des moteurs
% =========================================================================
ID = 3;                                 % ID du moteur terminal
maquette = robot('real',PORT,1000000);  % Connexion aux moteurs
pause(0.5)

% 2.1.6 : utilisation de la fonction setStepPosition
% -------------------
%------------------------------------------------------
maquette.setStepPosition(ID,200)

% pause(0.5)
% 2.1.7 : utilisation de la fonction setSpeed
% -------------------------------------------------------------------------
% maquette.setSpeed(ID,256)


%%%%%%%%TP3%%%%%%%%%%%
%% 2.2 Caractérisation des actionneurs
% =========================================================================

% 2.2.12 : tracé des positions en fonction du temps
% -------------------------------------------------------------------------
% À compléter
pos_depart= 250;
pos_final= 900;

max_speed = 256;
maquette.setSpeed(ID,max_speed);
maquette.setStepPosition(ID,pos_depart);
pause(3);

speed_test = 64;

pos_hist=[];
time_hist=[];
speed_hist= [];

maquette.setSpeed(ID,speed_test);
maquette.setStepPosition(ID,pos_final);


tic

while(maquette.isMoving(ID))
    pos_now= maquette.getStepPosition(ID);
    speed_now =  val2speed(maquette.getSpeed(ID));
    pos_hist(end+1)= pos_now;
    speed_hist(end+1)= speed_now;
    time_hist(end+1)=toc;
end
maquette.close()


%%

p = step2angle(pos_hist,512);
plot(time_hist,p)
xlabel('Time[s]')
ylabel('Position [step]')
grid on

return


%En faisant varier la vitesse on observe que la pente de la courbe de
%position change, elle croit proportionnelement avec la vitesse
%%
% 2.2.14 : tracé des vitesses en fonction du temps
% -------------------------------------------------------------------------
plot(time_hist,speed_hist)
xlabel('Time[s]')
ylabel('Speed [step]')
grid on
return

% On observe que les courbes sont similaires, seulement les valeurs
% diffèrent étant donné que la première courbe est en step et l'autre en
% tour/min
%%
% 2.2.15 : tracé des positions estimées par différence finie
% -------------------------------------------------------------------------

q_rad = step2angle(pos_hist, 512);
vitesse_rad_s = diff(q_rad) ./ diff(time_hist);
vitesse_estimee = vitesse_rad_s * (60 / (2 * pi));

plot(time_hist(1:end-1), vitesse_estimee) 
xlabel('Time[s]')
ylabel('Vitesse [tour/min]')
grid on
return
maquette.close()

%On remarque que cette méthode par différencie nous donne une courbe
%bruitée. La courbe est moins précise car l'erreure augmente par la
%différence finie
%%

% 2.2.16 : répétabilité des vitesses et positions 
% -------------------------------------------------------------------------
% À compléterpos_depart= 250;


erreur =[]
for i = 1:3
    
    pos_depart= 250;
    pos_final= 900;
    max_speed = 256;
    maquette.setSpeed(ID,max_speed);
    maquette.setStepPosition(ID,pos_depart);
    pause(3);
    
    speed_test = [512,512,512];
    
    maquette.setSpeed(ID,speed_test(i));
    maquette.setStepPosition(ID,pos_final);
    pos_hist=[];
    time_hist=[];
    speed_hist= [];
    tic;
    while(maquette.isMoving(ID))
      pos_now= maquette.getStepPosition(ID);
      speed_now =  val2speed(maquette.getSpeed(ID));
      pos_hist(end+1)= pos_now;
      speed_hist(end+1)= speed_now;
      time_hist(end+1)=toc;
    end
    erreur(i) = pos_final - pos_hist(end)
    p = step2angle(pos_hist,512);
    plot(time_hist,p)
    hold on
    xlabel('Time[s]')
    ylabel('Position [step]')
    grid on
    title("Pas moteur en fonction du temps pour différentes vitesses")
end

s= 0
for i = 1:3
    s = s + erreur(i)
end 
moy = s/3

% Pour une vitesse de 512 on a une moyenne d'erreur de 2
% Pour une vitesse de 256 on a une moyenne d'erreur de 1.6667
% Pour une vitesse de 128 on a une moyenne d'erreur de 1
% Pour une vitesse de 64 on a une moyenne d'erreur de 0.333

