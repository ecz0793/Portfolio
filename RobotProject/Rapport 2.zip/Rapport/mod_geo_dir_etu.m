function THf = mod_geo_dir_etu(modele)
% MOD_GEO_DIR retourne la matrice de transformation homogène associée à
% l'organe terminal du modèle
%   THf = mod_geo_dir(modele)

% Vecteur contenant la longueur des segments
long_segment = modele.bodyLength;
    
% Vecteur contenant les configurations articulaires en rad
conf_artic = modele.getAngularPosition();

TH_f = eye(4);

for i= 1:length(long_segment)
       R = rotation_Z_etu(conf_artic(i));
       THi = TH_f* trans_homogene_etu(R,[0;0;0]);
       T =[long_segment(i);0;0];
       H = trans_homogene_etu(eye(3),T);
       TH_f = THi*H
% A COMPLETER
end

end
