function [a] = inv_rotation_Z_etu(R)

a = atan2(R(2,1),R(1,1))
end
