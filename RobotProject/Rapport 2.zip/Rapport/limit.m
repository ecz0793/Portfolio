function new_pos = limit(pos,val_min,val_max)
% LIMIT(POS,VAL_MIN,VAL_MAX) limite les valeurs de position dans le 
% vecteur POS entre une valeur minimale VAL_MIN et maximale VAL_MAX 
% autorisée par la geometrie du robot.

new_pos=zeros(1,length(pos));
if pos < val_min
    new_pos= val_min
    
elseif pos > val_max
    new_pos=val_max
else
    new_pos=pos
end
end

