function p = angle2step(q,offset)
% ANGLE2STEP convertit la valeur angulaire Q (rad) en une valeur de pas
% moteur P.
% OFFSET permet de sp�cifier � quelle valeur de pas moteur correspond la
% valeur angulaire 0.
% 
% p = angle2step(q,offset);
%p = q*(pi/180)*(512/(150*pi/180))+offset ;
p =offset + q*(180*1023)/(300*pi)
end