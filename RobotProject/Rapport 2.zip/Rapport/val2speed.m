function v = val2speed(value)
% VAL2SPEED convertit la valeur de vitesse VALUE lue sur le moteur en une 
% valeur de vitesse V exprim�e en tour/min.
% 
% v = val2speed(value);
if (value<1024)
    v = value* 0.111;
else
    v = (value-1024)* 0.111;

end
