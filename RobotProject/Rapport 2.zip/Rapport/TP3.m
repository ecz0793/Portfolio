clear
clc

% Paramètres de la communications série
PORT = 11; 
BAUD = 1000000;% A modifier avec le n° du port COM utilisé
%%
ID = 3;
% ID du moteur terminal
segment=[0.5,0.5,0.5];
modele = robot('model',segment);  % Connexion aux moteurs
maquette = robot('real',PORT,BAUD);  % Connexion aux moteurs

%%

pos =700.18;
maquette.setStepPosition(ID,pos);

p1 = maquette.getStepPosition(1);
q1 = step2angle(p1,512);
p2 = maquette.getStepPosition(2);
q2 = step2angle(p2,512);
p3 = maquette.getStepPosition(3);
q3 = step2angle(p3,512);
modele.setAngularPosition([q1,q2,q3]);
modele.plot(0,"red",0);

%%

q4 = [300,400,550];
q5 = [400,450,300];
q6 = [512,512,512];
maquette.setSpeed(1,32)
maquette.setSpeed(2,32)
maquette.setSpeed(3,32)
val_min = 50;
val_max= 950;
%%
modele.setAngularPosition(q4);
T = modele.mod_geo_dir();

x1 = T(1,4);
y1 = T(2,4);
theta1 = inv_rotation_Z_etu(rotation_Z_etu(step2angle(q4(3),512)));
p1n = limit(q4,val_min,val_max);
maquette.setStepPosition([1,2,3],p1n);
modele.setAngularPosition(step2angle(q4,512))
pause(3);
%Validation des valeurs numériques sur le modèle physique
%%
modele.setAngularPosition(q5)
T = modele.mod_geo_dir();
x2 = T(1,4);
y2 = T(2,4);
theta2 = inv_rotation_Z_etu(rotation_Z_etu(step2angle(q5(3),512)));
p2n = limit(q5,val_min,val_max);
maquette.setStepPosition([1,2,3],p2n)
modele.setAngularPosition(step2angle(q5,512))
pause(3)
%Validation des valeurs numériques sur le modèle physique
%%
modele.setAngularPosition(q6)
T = modele.mod_geo_dir();
T;
x = T(1,4);
y = T(2,4);
theta3 = inv_rotation_Z_etu(rotation_Z_etu(step2angle(q6(3),512)));
p3n = limit(q6,val_min,val_max);
maquette.setStepPosition([1,2,3],p3n)
modele.setAngularPosition(step2angle(q6,512))
pause(3)
%Validation des valeurs numériques sur le modèle physique
modele.plot(0,"red",0);
%%
%Q4
% Sans interpolation, chaque moteur se déplace indépendamment vers sa
% consigne articulaire finale. La trajectoire de l'organe terminal dans
% l'espace opérationnel est donc courbe et non maîtrisée : on contrôle
% uniquement la pose finale, pas le chemin parcouru.

%%
%Q5
val_min = 50;
val_max = 950;
cibleA = [1; 1; pi/4];
[sol1, sol2] = modele.mod_geo_inv(cibleA(1), cibleA(2), cibleA(3));

sol1_steps = angle2step(sol1, 512);
sol2_steps = angle2step(sol2, 512);

sol1_ok = all(sol1_steps >= val_min & sol1_steps <= val_max);
sol2_ok = all(sol2_steps >= val_min & sol2_steps <= val_max);

if sol1_ok
    q_choisi_rad   = sol1;
    q_choisi_steps = sol1_steps;

elseif sol2_ok
    q_choisi_rad   = sol2;
    q_choisi_steps = sol2_steps;

else
    error('Aucune solution');
end

modele.setAngularPosition(q_choisi_rad);
T_verif = modele.mod_geo_dir();
%modele.plot(0, 'red', 0);

maquette.setStepPosition([1, 2, 3], q_choisi_steps);

%% Q6
while any(maquette.isMoving([1, 2, 3]))

   p_c = maquette.getStepPosition([1, 2, 3]);
   q_c = step2angle(p_c, 512);
   modele.setAngularPosition(q_c);
   T_courant = modele.mod_geo_dir();
   x_c  = T_courant(1, 4);
   y_c  = T_courant(2, 4);
   modele.plot(0, 'red', 1);
   pause(0.05);
   
end

p_reel = maquette.getStepPosition([1, 2, 3]);
q_reel = step2angle(p_reel, 512);
modele.setAngularPosition(q_reel);
T_reel = modele.mod_geo_dir();


%% Partie 3

% Position Initiale 
x0 = 1;
y0 = 1;
theta0 =  pi/4;

% Position finale 
x_f     = -1;
y_f     = 1;
theta_f = pi/4;

maquette.setSpeed(1,80)
maquette.setSpeed(2,80)
maquette.setSpeed(3,80)
n = 50; % nombre de points intermediaire 

t = linspace(0, 1, n+1);
x_traj = x0+ t *(x_f - x0); %equation d'un segment 
y_traj = y0+ t *(y_f - y0);
theta_traj = theta0 + t*(theta_f - theta0);

q_traj = zeros(n+1, 3);  
q_prec = zeros(1, 3); 

for i = 1:n+1
    [q1, q2] = modele.mod_geo_inv(x_traj(i), y_traj(i), theta_traj(i));

    q1_steps = angle2step(sol1, 512);
    q2_steps = angle2step(sol2, 512);

    q1_ok = all(q1_steps >= val_min & q1_steps <= val_max); %On verifie qu'on ne depasse pas les limites 
    q2_ok = all(q2_steps >= val_min & q2_steps <= val_max);

    if q1_ok && q2_ok  %alors on choisit en fonction de la distance parcourue 
        
        dist1 = norm(q1 - q_prec);
        dist2 = norm(q2 - q_prec);
        if dist1 <= dist2
            q_traj(i,:) = q1;
        else
            q_traj(i,:) = q2;
        end
    elseif q1_ok
        q_traj(i,:) = q1;
    elseif sol2_ok
        q_traj(i,:) = q2;
    else
        error('inaccessible', i);
    end

    q_prec = q_traj(i,:);   % Mise à jour pour le prochain point
end


%%
x_reel = zeros(1, n+1);
y_reel = zeros(1, n+1);

steps_depart = angle2step(q_traj(1,:), 512);
steps_dl = limit(steps_depart, val_min, val_max);
maquette.setStepPosition([1,2,3], steps_dl);

% Boucle qui permet d'afficher en direct le robot sur le modele
 while any(maquette.isMoving([1, 2, 3]))
     p_c = maquette.getStepPosition([1, 2, 3]);
     q_c = step2angle(p_c, 512);
     modele.setAngularPosition(q_c);
     T_courant = modele.mod_geo_dir();
     x_c  = T_courant(1, 4);
     y_c  = T_courant(2, 4);
     modele.plot(0, 'red', 1);
     pause(0.05);
   
    end

for i = 1:n+1

    q_steps = angle2step(q_traj(i,:), 512);
    q_sl = limit(q_steps, val_min, val_max);
    
    maquette.setStepPosition([1,2,3], q_sl);

    while any(maquette.isMoving([1, 2, 3]))% Boucle qui permet d'afficher en direct le robot sur le modele
     p_c = maquette.getStepPosition([1, 2, 3]);
     q_c = step2angle(p_c, 512);
     modele.setAngularPosition(q_c);
     T_courant = modele.mod_geo_dir();
     x_c  = T_courant(1, 4);
     y_c  = T_courant(2, 4);
     modele.plot(0, 'red', 1);
     pause(0.05);
   
    end

    p_reel = maquette.getStepPosition([1,2,3]);
    q_reel = step2angle(p_reel, 512);

    modele.setAngularPosition(q_reel);
    T_reel = modele.mod_geo_dir();
    x_reel(i) = T_reel(1,4);
    y_reel(i) = T_reel(2,4);

    if i == 1
        modele.plot(0, 'red', 0);
    else
        modele.plot(1, 'red', 1);
    end
end

% Plus le nombre de points intermédiaires augmentent plus la trajectoire
% est droite  

