clear all
close all

%% 2.2/ Construction et affichage d’un 3R plan
% =========================================================================
% Question 2.2.1 : déclaration du modèle r3
% -------------------------------------------------------------------------
% CODE A COMPLETER
modele = robot('model',[0.5,0.3,0.2])
modele2 = robot('model',[0.5,0.3,0.2])
modele.setAngularPosition([0,0,0])
position = modele.getAngularPosition()
% Question 2.2.2 : affichage du modèle
% -------------------------------------------------------------------------
% CODE A COMPLETER
modele.plot(0,'blue',0)
% Question 2.2.3 : robot r3 en [pi/2,0,0] + vérification graphique
% -------------------------------------------------------------------------
% CODE A COMPLETER
modele.setAngularPosition([pi/2,0,0])
modele.plot(0,'blue',0)
%% 2.3/ Fonctionnalités élémentaires
%----------------------------------------------------------------------

% Question 2.3.1 : matrice de rotation d’un angle alpha autour de l’axe Z
rotation_Z_etu(pi/2)

% Question 2.3.2 : retourne alpha à partir d’une matrice de rotation
b = inv_rotation_Z_etu(rotation_Z_etu(pi/2))


% Question 2.3.3 : matrice de transformation homogène
% -------------------------------------------------------------------------
% CODE A COMPLETER
trans_homogene_etu(rotation_Z_etu(pi/4),[1;2;3])
%% 2.4/ Calcul du modèle géométrique direct et inverse
%----------------------------------------------------------------------

% Question 2.4.1 : fonction matlab qui retourne les matrices de transformation homogène
% -------------------------------------------------------------------------
% CODE A COMPLETER
mod_geo_dir_etu(modele)

% Question 2.4.2 : Tester la fonction mod_geo_dir_etu() 
% -------------------------------------------------------------------------
% CODE A COMPLETER
mod_geo_dir_etu(modele)
modele.mod_geo_dir()
% Question 2.4.3 : Utilisation du modèle inverse
% -------------------------------------------------------------------------
% CODE A COMPLETER

!Trivial
cible = [0.5 0.5 pi/2]
[q1,q2] = modele.mod_geo_inv(cible(1),cible(2),cible(3))


modele.setAngularPosition(q1)
modele.plot(0,'red',0)

modele.setAngularPosition(q2)
modele.plot(0,'red',0)

% Question 2.4.4 : cible [1.0 1.0 3*pi/2]
% -------------------------------------------------------------------------
% CODE A COMPLETER
cible = [1.0 1.0 3*pi/2]
[q5,q6] = modele.mod_geo_inv(cible(1),cible(2),cible(3))

modele.mod_geo_dir()
%% 3) Génération de trajectoires par interpolation
% =========================================================================

% Question 3.1.1 : interpolation articulaire
% -------------------------------------------------------------------------
% CODE A COMPLETER

qinit = [pi/4 0 -pi/4];
modele.setAngularPosition(qinit)
modele.plot(0,'red',0)

modele2.setAngularPosition(qinit)
modele2.plot(0,'blue',0)


cible = [-0.4 0.4 pi/2];
[q1,q2] = modele.mod_geo_inv(cible(1),cible(2),cible(3));

% qfin = q1;

N = 100;

for i = 0:N
    qnow1 = qinit + i * (q1 - qinit) / N;
    modele.setAngularPosition(qnow1)
    modele.plot(0,'red',0)
    
  
    qnow2 = qinit + i * (q2 - qinit) / N;
    modele2.setAngularPosition(qnow2)
    modele2.plot(1,'blue',0)
    pause(2/N)
end



% Question 3.1.2 : avantages/inconvénients
% -------------------------------------------------------------------------

% Question 3.2.1 : interpolation opérationnelle
% -------------------------------------------------------------------------
% CODE A COMPLETER

% Question 3.2.2 : avantages/inconvénients
% -------------------------------------------------------------------------


